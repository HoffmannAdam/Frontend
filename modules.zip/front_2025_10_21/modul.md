# Modul

`node -v`
`npm -v`

`npm create vite@latest modul-js-alapok -- --template vanilla`

`cd modul-js-alapok`
`npm install`
`npm run dev`

- src mappa alatt modules és pages mappa.