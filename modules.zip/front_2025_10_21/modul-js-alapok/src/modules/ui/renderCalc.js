export function renderCalc() {
    const valami = document.createElement('p');
    valami.textContent = "itt lenne a számológép!!!";
}